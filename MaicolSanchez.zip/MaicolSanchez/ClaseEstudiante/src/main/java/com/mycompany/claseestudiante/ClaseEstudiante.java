/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.claseestudiante;
/**
 *
 * @author Aprendiz
 */
public class ClaseEstudiante {

    public static void main(String[] args) {
        
        
        Estudiantes Maicol = new Estudiantes("maicol",2.5,3.0);
        Maicol.promedio(2.5,5.0);
        Maicol.aprobo();
    }
}
